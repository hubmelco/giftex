/*
IMPORTANT
Go to the following links for a guide on how to set up and use the server.
https://gitlab.com/msoe.edu/sdl/y21sdl/group-giftex/giftex/-/wikis/Setting-Up-and-Running-the-Server
https://gitlab.com/msoe.edu/sdl/y21sdl/group-giftex/giftex/-/wikis/Using-the-Server

If these links don't work the files can also be found in the repository
/Docs/Wiki/Setting Up and Running the Server.md
/Docs/Wiki/Using the Server.md
*/
const mysql = require('mysql');
const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const unirest = require("unirest");
const amazonReq = unirest("GET", "https://rapidapi.p.rapidapi.com/amz/amazon-lookup-product");
require('dotenv').config();
const bcrypt = require('bcrypt');
const request = require('request');
const jwt = require("jsonwebtoken");
// const checkoutNodeJssdk = require('@paypal/checkout-server-sdk');
const fs = require("fs");
const path = require('path');


//const request = require('request');

//import axios from "axios";
//comment to trigger commit

app.use(cors());

app.use(express.urlencoded({extended: true}));

app.use(express.json());

app.use(bodyParser.urlencoded({
    extended: true
}));

app.listen(3001, () => {
    console.log("Server is running at " + process.env.REACT_APP_HOSTNAME);
});

const con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: process.env.REACT_APP_DB_PASS,
    database: "giftaccount"
});

//NOTE: The response of all post commands will contain a status value
//NOTE: The response of all get (starting with get) commands will only contain a status value when something goes wrong or a special case has occurred

//Account
app.post("/signup", handleSignUp);
app.post("/login", handleLogin);
//app.post("/logout", authenticateToken, handleLogout); //Unnecessary
app.post("/changeProfile", authenticateToken, handleChangeProfile); // Handles changes to a profile for all the parameters passed in. Will not handle parameters that cannot change or are not recognized.
//app.post("/changePassword", handleChangePassword); //TODO: requires an email service, save for later
app.post("/sendFriendRequest", authenticateToken, handleSendFriendRequest); // Sends a friend request
app.post("/friendRequest", authenticateToken, handleFriendRequest); // Accepts or declines a friend request based on what is passed in for response (in the json request)
app.post("/getIncomingFriendRequests", authenticateToken, handleGetIncomingFriendRequests);
app.post("/getOutgoingFriendRequests", authenticateToken, handleGetOutgoingFriendRequests);
app.post("/removeFriend", authenticateToken, handleRemoveFriend);
app.post("/addGift", authenticateToken, handleAddGift);
app.post("/removeGift", authenticateToken, handleRemoveGift);
app.post("/getProfileSnapshot", authenticateToken, handleGetProfileSnapshot); // returns name and picture, only name if profile is private
app.post("/getProfileInfo", authenticateToken, handleGetProfileInfo); // returns a json with non-list profile information (name, address, dob, bio, pic, etc)
app.post("/getProfileActivity", authenticateToken, handleGetProfileActivity);
app.post("/getProfileGifts", authenticateToken, handleGetProfileGifts);
app.post("/getProfileFriends", authenticateToken, handleGetProfileFriends);
app.post("/getAddresses", authenticateToken, handleGetAddresses);
app.post("/addAddress", authenticateToken, handleAddAddress);
app.post("/deleteAddress", authenticateToken, handleDeleteAddress);
app.post("/changeAddress", authenticateToken, handleChangeAddress);
app.post("/getWalletFunds", authenticateToken, handleGetWalletFunds);
app.post("/searchProfile", authenticateToken, handleSearchProfile);

app.post("/allNames", handleAllNames);
app.post("/allGifts", handleAllGifts)

//Gift
app.post("/getTopGifts", handleGetTopGifts); //Returns a json of the snapshot information for all gifts that are not private //TODO: Currently debug method, requires refactoring for search algorithm
app.post("/contribute", authenticateToken, handleContribute);
app.post("/refund", authenticateToken, handleRefund); //TODO: FIX ISSUES IN SPRINT 2 Q2
app.post("/getGiftSnapshot", authenticateToken, handleGetGiftSnapshot);
app.post("/getGiftInfo", authenticateToken, handleGetGiftInfo);
app.post("/getGiftImages", authenticateToken, handleGetGiftImages);
app.post("/addComment", authenticateToken, handleAddComment);
app.post("/deleteComment", authenticateToken, handleDeleteComment);
app.post("/getComments", authenticateToken, handleGetComments);
app.post("/changeGift", authenticateToken, handleChangeGift); // Handles changes to a gift for all the parameters passed in. Will not handle parameters that cannot change or are not recognized. //TODO: TEST
app.post('/getAmazonProductInfo', authenticateToken, handleGetAmazonProductInfo)

//Paypal
app.post("/paypal/create-payment/", authenticateToken, handlePaypalCreatePayment);
app.post("/paypal/execute-payment/", authenticateToken, handlePaypalExecutePayment);

//This should be in the .env file later.
let PAYPAL_CLIENT = 'AYNVwNMXHj6ajaXiU-R7AQma7pJfNURhQu-fOuMBRwC3FUXzh0M5gjQPM_sB2jxnWivXTTIa-_1lU0mp';
let PAYPAL_SECRET = 'EKrb43kIP2LMfSYYgiE4Qr2qtTJd-VeilMvcyU04yLaiadjEhk6TFfu2j_VrEEF9yrz4hPf19j5dbzJv';
let PAYPAL_API = 'https://api-m.sandbox.paypal.com';

//JWT authentication
function authenticateToken(request, response, next){
    const authHeader = request.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if(token === undefined) return response.json({status:"no token attached"});
    jwt.verify(token, process.env.REACT_APP_JWT_SECRET, (err, user) => {
        if (err) return response.json({status:"authorization prohibited"});
        //console.log("User: " , user);
        request.body.login = user.email;
        next();
    });
}


// /signup                      {email, password, name, dob, priv}
/**
 * #### /signup

 **Auth tokens required:** No

 **Required parameters:** `email`, `password`, `name`, `dob`, `priv`

 **Optional parameters:** N/A

 Creates a new account with the requested values. The profile picture is also set to the default profile picture. Will respond with status "already exists" if the email is already in use.

 `email` - Email of new account.

 `password` - Password of the new account.

 `name` - Name of the new account.

 `dob` - Date of birth.

 `priv` - Privacy of the account. 1 if the account is private and 0 if it is not.

 */
let salt = 8;
function handleSignUp(request, response) {
    request = request.body;
    //console.log(request);
    existAccount(request.email, function(result) {
        if(!result) {
            bcrypt.hash(request.password, salt, (err, encrypted) => {
                let sql = "INSERT INTO account (email, password, name, dob, priv, pic)" +
                    " VALUES (?, ?, ?, convert(?, date), ?, ?)";
                con.query(sql,
                    [request.email, encrypted, request.name, request.dob, request.priv, fs.readFileSync(path.dirname(require.main.filename) + "\\defaultProfilePic.png")],
                    function (err) {
                    if (err) throw err;
                    response.json({status:"ok"});
                });
            })
        } else {
            response.json({status:"already exists"});
        }
    });
}

// /login                       {login, password}
/**
 #### /login

 **Auth tokens required:** No

 **Required parameters:** `login`, `password`

 **Optional parameters:** N/A

 Logs in the user. If log in is successful it responds with a success value of true and the access token for the account. If the password is incorrect it responds with status "incorrect password" and a success value of false. If the account does not exist it responds with status "account does not exist" and a success value of false.

 `login` - Email of the logged in account.

 `password` - Password of the user's account.
 */
function handleLogin(request, response) {
    request = request.body;
    existAccount(request.login, function(exist) {
        if(exist) {
            getAccount(request.login, function(account) {
                //Decrypt password.
                bcrypt.compare(request.password, account.password, function(err, res){
                    if(res){
                        const user = {email: account.email, password: account.password};
                        const accessToken = jwt.sign(user, process.env.REACT_APP_JWT_SECRET);
                        // //This is only temporary Danny don't freak out
                        //     const user = {email: res[0].EMAIL, name: res[0].FIRSTNAME};
                        //     const accessToken = jwt.sign(user, process.env.REACT_APP_JWT_SECRET);
                        response.json({status:"ok", success:true, token: accessToken});
                    } else {
                             response.json({status:"incorrect password", success:false});
                    }
                })
                // if(request.password === account.password) {
                //     con.query("update Account set loginDevice='" + request.loginDevice + "' where email='" + request.login + "'",
                //         function (err, results) {
                //         if (err) throw err;
                //         const user = {email: account.email, password: account.password, loginDevice: request.loginDevice};
                //         const accessToken = jwt.sign(user, process.env.REACT_APP_JWT_SECRET);
                //         // //This is only temporary Danny don't freak out
                //         //     const user = {email: res[0].EMAIL, name: res[0].FIRSTNAME};
                //         //     const accessToken = jwt.sign(user, process.env.REACT_APP_JWT_SECRET);
                //         response.json({status:"ok", success:true, loginDevice: request.loginDevice, token: accessToken});
                //     });
                // } else {
                //     response.json({status:"incorrect password", success:false});
                // }
            });
        } else {
            response.json({status:"account does not exist", success:false});
        }
    });

}

// /logout                      {login}
// Unnecessary
// function handleLogout(request, response) {
//     request = request.body;
//     con.query("update Account set loginDevice='' where email=?",
//         request.login,
//         function (err) {
//         if (err) throw err;
//         response.json({status: "ok"});
//     });
// }

// /changeProfile               {login, name, priv, pic, bio, primAddressID}
// NOTE: All the request parameters are optional except for login
/**
 #### /changeProfile

 **Auth tokens required:** Yes

 **Required parameters:** `login`

 **Optional parameters:** `name`, `priv`, `pic`, `bio`, `primAddressID`

 Changes information on a profile based on what is passed in. Will respond with a status listing the values changed.

 `login` - Email of the logged in account.

 `name` - New name of the account.

 `priv` - The new privacy status of the account.

 `pic` - The new profile picture of the account.

 `bio` - The new bio of the account.

 `primAddressID` - The new primary address id. This is an integer corresponding to one of the addresses associated with the account.
 */
function handleChangeProfile(request, response) {
    request = request.body;
    getAccount(request.login, function (account) {
        let retName = account.name;
        //let retDOB = account.DOB;
        let retPriv = account.priv;
        let retPic = account.pic;
        let retBio = account.bio;
        let retPrimAddressID = account.primAddressID;
        let changeLog = [];

        if(request.hasOwnProperty('name')) {
            retName = request.name;
            changeLog.push("name");
        }
        /*if(request.hasOwnProperty('DOB')) {
            retDOB = request.DOB;
            changeLog.push("DOB");
        }*/
        if(request.hasOwnProperty('priv')) {
            retPriv = request.priv;
            changeLog.push("priv");
        }
        if(request.hasOwnProperty('pic')) {
            retPic = request.pic;
            changeLog.push("pic");
        }
        if(request.hasOwnProperty('bio')) {
            retBio = request.bio;
            changeLog.push("bio");
        }
        if(request.hasOwnProperty('primAddressID')) {
            retPrimAddressID = request.primAddressID;
            changeLog.push("primAddressID");
        }

        con.query("update Account set name=?, " +
            //"DOB=convert('" + retDOB + "', date), " +
            "priv=?, " +
            "pic=?, " +
            "bio=?, " +
            "primAddressID=? " +
            "where email=?",
            [retName, retPriv, retPic, retBio, retPrimAddressID, request.login],
            function (err, results) {
            if (err) throw err;
            //console.log(results);
            response.json({status:"ok - values changed: " + changeLog});
        });
    });
}

// /sendFriendRequest           {login, email}
/**
 #### /sendFriendRequest

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `email`

 **Optional parameters:** N/A

 Sends a friend request to the desired account.

 `login` - Email of the logged in account.

 `email` - Email of the account the friend request is being sent to.
 */
function handleSendFriendRequest(request, response) {
    request = request.body;
    existAccount(request.email, function (exist) {
        if (exist) {
            con.query("select count(*) as n from Friend_Request where sendingEmail=? and receivingEmail=?",
                [request.login, request.email],
                function (err, results) {
                if (err) throw err;
                if (results[0].n === 0) {
                    con.query("select count(*) as n from Friend_Request where sendingEmail=? and receivingEmail=?",
                        [request.email, request.login],
                        function (err, results) {
                        if (err) throw err;
                        if (results[0].n === 0) {
                            con.query("insert into Friend_Request (sendingEmail, receivingEmail, date) values (?, ?, convert('" + getCurrentDate() + "', date))",
                                [request.login, request.email],
                                function (err) {
                                    if (err) throw err;
                                    response.json({status: "ok"});
                                });
                        } else {
                            response.json({status: "request already sent by target"});
                        }
                    });
                } else {
                    response.json({status: "request already exists"});
                }
            });
        } else {
            response.json({status:"account does not exist"});
        }
    });
}

// /friendRequest               {login, email, response}
/**
 #### /friendRequest

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `email`, `response`

 **Optional parameters:** N/A

 Accepts or denies a received friend request, adding the friend if accepted and deleting the request if denied.

 `login` - Email of the logged in account.

 `email` - Email of the friend request sender.

 `response` - True if the friend request is accepted. False if friend request is denied.
 */
function handleFriendRequest(request, response) {
    request = request.body;
    if(request.response) {
        con.query("insert into account_friends (email, friends) values (?, ?)",
            [request.login, request.email],
            function (err) {
            if (err) throw err;
            con.query("insert into account_friends (email, friends) values (?,?)",
                [request.email, request.login],
                function (err) {
                if (err) throw err;
                con.query("delete from Friend_Request where sendingEmail=? and receivingEmail=?",
                    [request.email, request.login],
                    function (err) {
                    if (err) throw err;
                    let date = getCurrentDateTime();
                    con.query("insert into Account_Activity (email, date, type, otherEmail) values (?, convert('" + date + "', datetime), 'ADD_FRIEND', ?)",
                        [request.login, request.email],
                        function (err) {
                        if (err) throw err;
                        con.query("insert into Account_Activity (email, date, type, otherEmail) values (?, convert('" + date + "', datetime), 'ADD_FRIEND', ?)",
                            [request.email, request.login],
                            function (err) {
                                if (err) throw err;
                                response.json({status: "ok, request accepted"});
                        });
                    });
                });
            });
        });
    } else {
        con.query("delete from Friend_Request where sendingEmail=? and receivingEmail=?",
            [request.email, request.login],
            function (err) {
                if (err) throw err;
                response.json({status:"ok, request denied"});
        });
    }
}

// /getIncomingFriendRequests   {login}
/**
 #### /getIncomingFriendRequests

 **Auth tokens required:** Yes

 **Required parameters:** `login`

 **Optional parameters:** N/A

 Responds with a list of incoming friend requests. Each entry has the values `sendingEmail`, `date`, `date`, and `name`.

 `login` - Email of the logged in account.
 */
function handleGetIncomingFriendRequests(request, response) {
    request = request.body;
    con.query("select sendingEmail, date, name, pic from Friend_Request inner join account on sendingEmail=email where receivingEmail=?",
        request.login,
        function (err, results) {
            if (err) throw err;
            let ret = [];
            let i = 0;
            results.forEach(function (entry) {
                    ret.push({sendingEmail:entry.sendingEmail, date:entry.date, name: entry.name, pic: convertBlobToImg(entry.pic)});
                i++;
            });
            response.json(ret);
        });
}

// /getOutgoingFriendRequests   {login}
/**
 #### /getOutgoingFriendRequests

 **Auth tokens required:** Yes

 **Required parameters:** `login`

 **Optional parameters:** N/A

 Responds with a list of outgoing friend requests. Returns the `receivingEmail` and `date` for each entry.

 `login` - Email of the logged in account.
 */
function handleGetOutgoingFriendRequests(request, response) {
    request = request.body;
    con.query("select receivingEmail, date from Friend_Request where sendingEmail=?",
        request.login,
        function (err, results) {
            if (err) throw err;
            response.json(results);
        });
}

// /removeFriend                {login, email}
/**
 #### /removeFriend

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `email`

 **Optional parameters:** N/A

 Removes the requested account from the user's friend list.

 `login` - Email of the logged in account.

 `email` - Email of friend account being removed.

 */
function handleRemoveFriend(request, response) {
    request = request.body;
    con.query("delete from account_friends where email=? and friends=?",
        [request.login, request.email],
        function (err) {
        if (err) throw err;
        con.query("delete from account_friends where email=? and friends=?",
            [request.email, request.login],
            function (err) {
            if (err) throw err;
            response.json({status:"ok"});
        });
    });
}

// /addGift                     {login, name, email, price, thumbnail, description, link, priv, deadline}
/**
 #### /addGift

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `name`, `email`, `price`, `thumbnail`, `description`, `link`, `priv`, `deadline`

 **Optional parameters:** N/A

 Adds a gift to the database with the requested information. Performs all necessary associations involved with creating a gift.

 `login` - Email of the logged in account.

 `name` - Name of the new gift.

 `email` - Email of the account receiving the gift.

 `price` - The price of the gift

 `thumbnail` - Link to an image which will be the thumbnail of the gift.

 `description` - Description of the gift.

 `link` - Link to the gift. This is likely an Amazon link or some

 `priv` - The privacy status of the gift. A private gift can only be viewed by friends of the poster. 1 if private, 0 if not.

 `deadline` - Deadline of the gift. This is the day by which the gift must be funded. Date formatted as <YYYY-MM-DD>.
 */
function handleAddGift(request, response) {
    request = request.body;
    console.log(request);
    existAccount(request.email, function (exist) {
        if (exist) {
            getAccount(request.email, function (accountOther) {
                getAccountFriends(request.login, function (friends) {
                    if (request.login===request.email || !accountOther.priv || friends.includes(request.email)) {
                        let sqlReq1 = "";
                        let sqlReq2 = "";
                        let sqlVal = [request.name, request.login, request.email, request.price, request.thumbnail, request.description, request.link, request.priv];
                        if(request.deadline !== '') {
                            sqlReq1 = "deadline, ";
                            sqlReq2 = "?, ";
                            sqlVal.push(request.deadline);
                        }

                        con.query("insert into Gift (name, accountEmail, receivingEmail, price, thumbnail, description, link, priv, " + sqlReq1 + "date)" +
                            "values (?, ?, ?, ?, ?, ?, ?, ?, " + sqlReq2 + "convert('" + getCurrentDateTime() + "', datetime))",
                            sqlVal,
                            function (err) {
                            if (err) throw err;
                            con.query("select last_insert_id() as n", function (err, results) {
                                if (err) throw err;
                                let giftID = results[0].n;
                                con.query("insert into Gift_Account (email, giftID) values ('" + request.login +
                                    "', '" + giftID + "')", function (err, results) {
                                    if (err) throw err;
                                    con.query("insert into Image (giftID, image) values ('" + giftID + "', ?)",
                                        request.thumbnail,
                                        function (err, results) {
                                            if (err) throw err;
                                            con.query("insert into Account_Activity (email, date, type, otherEmail, ID) " +
                                                "values (?, convert('" + getCurrentDateTime() +
                                                "', datetime), 'POST_GIFT', ?, " + giftID + ")",
                                                [request.login, request.email],
                                                function (err) {
                                                    if (err) throw err;
                                                    response.json({status: "ok", giftID: giftID});
                                                });
                                        });
                                });
                            });
                        });
                    } else {
                        response.json({status: "receiving account is private"})
                    }
                });
            });
        } else {
            response.json({status:"account does not exist"});
        }
    });
}

// /removeGift                  {login, giftID}
/**
 #### /removeGift

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`

 **Optional parameters:** N/A

 Removes the desired gift with the requested id.

 `login` - Email of the logged in account.

 `giftID` - The numeric id value associated with the gift.
 */
function handleRemoveGift(request, response) {
    request = request.body;
    getAccount(request.login, function(account) {
        con.query("select email, amount from Gift_Log where giftID=? group by email",
            request.giftID,
            function(err, result) {
                if (err) throw err;
                result.forEach(function (entry) {
                    let newWallet = account.wallet + entry.amount;
                    con.query("update Account set wallet=? where email=?",
                        [newWallet, entry.email],
                        function (err) {
                            if (err) throw err;
                            con.query("delete from Gift_Log where email=?",
                                entry.email,
                                function (err) {
                                if (err) throw err;
                            });
                        });
                });
                con.query("delete from Gift_Account where giftID=?",
                    request.giftID,
                    function (err) {
                    if(err) throw err;
                    con.query("delete from Gift_Comments where giftID=?",
                        request.giftID,
                        function (err) {
                        if (err) throw err;
                        con.query("delete from Image where giftID=?",
                            request.giftID,
                            function (err) {
                            if (err) throw err;
                            con.query("delete from Gift where giftID=?",
                                request.giftID,
                                function (err) {
                                if (err) throw err;
                                response.json({status: "ok"});
                            });
                        });
                    });
                });
            });
    });
}

// /getProfileSnapshot          {login, email}
// NOTE: email can be an array or a single value
// WARNING: Output when email is an array is not in RowDataPackets like other methods.
/**
 #### /getProfileSnapshot

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `email`

 **Optional parameters:** N/A

 Responds with the name, email, and profile picture of the requested account. This is meant to be used in situations where you are displaying an account outside the profile page and only need a small amount of information. Can take in a list of emails to return a list of profile snapshots. Automatically refunds all contributions made.

 `login` - Email of the logged in account.

 `email` - An email or a list of email of requested accounts.
 */
function handleGetProfileSnapshot(request, response) {
    request = request.body;
    profileSnapshot(request.email, request.login, function (snapshots) {
        response.json(snapshots);
    });
}

// /getProfileInfo              {login, email}
/**
 #### /getProfileInfo

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `email`

 **Optional parameters:** N/A

 Responds with profile information to be displayed on a profile page. Will respond with less information of the account is private and the logged in user is not friends. Will return address information of the requested user is the logged in user or if the requested user is friends with the logged in user. DO NOT USE THIS OUTSIDE OF THE PROFILE PAGE.

 `login` - Email of the logged in account.

 `email` - Email of the requested account.
 */
function handleGetProfileInfo(request, response) {
    request = request.body;
    getAccount(request.email, function (accountOther) {
        getAccountFriends(request.login, function (friends) {
            if (request.login===request.email || !accountOther.priv || friends.includes(request.email)) {
                if(friends.includes(request.email) || request.login===request.email) {
                    con.query("select streetAddress, city, state, zipcode from Address where email=? and addressID=?",
                        [accountOther.email, accountOther.primAddressID],
                        function (err, result) {
                        //lol
                            if (err) throw err;
                            if(result.length === 0) {
                                response.json({
                                    email:accountOther.email,
                                    name: accountOther.name,
                                    dob: accountOther.DOB,
                                    pic: convertBlobToImg(accountOther.pic),
                                    bio: accountOther.bio,
                                    priv: accountOther.priv
                                });
                            } else {
                                response.json({
                                    email: accountOther.email,
                                    name: accountOther.name,
                                    dob: accountOther.DOB,
                                    pic: convertBlobToImg(accountOther.pic),
                                    bio: accountOther.bio,
                                    priv: accountOther.priv,
                                    streetAddress: result[0].streetAddress,
                                    city: result[0].city,
                                    state: result[0].state,
                                    zipcode: result[0].zipcode
                                });
                            }
                        });
                } else {
                    response.json({
                        name: accountOther.name,
                        dob: accountOther.DOB,
                        pic: convertBlobToImg(accountOther.pic),
                        bio: accountOther.bio
                    });
                }
            } else {
                response.json({
                    name: accountOther.name,
                    dob: accountOther.DOB,
                    pic: convertBlobToImg(accountOther.pic),
                    bio: accountOther.bio,
                    status:"authorization prohibited"
                });
            }
        });
    });
}

// /getProfileActivities        {login, email}
/**
 #### /getProfileActivity

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `email`

 **Optional parameters:** N/A

 Responds with the recorded activity of the requested profile. Responds with status "account is private" if the requested account is private and the logged in user is no friends.

 `login` - Email of the logged in account.

 `email` - Email of the requested account.
 */
function handleGetProfileActivity(request, response) {
    request = request.body;
    getAccount(request.email, function (accountOther) {
        getAccountFriends(request.login, function (friends) {
            if (request.login === request.email || !accountOther.priv || friends.includes(request.email)) {
                con.query("select gift.name as giftName, account1.name as otherName, account_activity.*, account.name from account, account account1, gift, account_activity where account_activity.email = account.email and account_activity.ID = gift.giftID and account_activity.email = ? and account_activity.otherEmail = account1.email;",
                    request.email,
                    function (err, result) {
                    if (err) throw err;
                    response.json(result);
                });
            } else {
                response.json({status:"account is private", name:accountOther.name});
            }
        });
    });
}

// /getProfileGifts             {login, email, description}
// NOTE: description is an optional parameter. Set it to true to also return the description
/**
 #### /getProfileGifts

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `email`

 **Optional parameters:** N/A

 Responds with gift snapshots with descriptions of the gifts of the requested account. Will not respond with private gifts if the logged in user is not friends.

 `login` - Email of the logged in account.

 `email` - Email of the requested account.
 */
function handleGetProfileGifts(request, response) {
    request = request.body;
    getAccount(request.email, function (accountOther) {
        getAccountFriends(request.login, function (friends) {
            if (request.login===request.email || !accountOther.priv || friends.includes(request.email)) {
                if(friends.includes(request.email) || request.login===request.email) {
                    con.query("select giftID from Gift_Account where email=?",
                        request.email,
                        function(err, results) {
                        if (err) throw err;
                        //console.log(1);
                        //console.log(results);
                        let desc = false;
                        if (request.hasOwnProperty("description") && request.description) {
                            desc = true;
                        }
                        console.log(results);
                        //response.json(results);
                        giftSnapshot(rowDataPacketToArray(results, "giftID"), desc, function (snapshots) {
                            response.json(snapshots);
                        });
                    });
                } else {
                    con.query("select a.giftID from Gift_Account a, Gift b where a.giftID=b.giftID and b.priv=0 and a.email=?",
                        request.email,
                        function(err, results) {
                        if (err) throw err;
                        //console.log(2);
                        giftSnapshot(rowDataPacketToArray(results, "a.giftID"), true, function (snapshots) {
                            response.json(snapshots);
                        });
                    });
                }
            } else {
                response.json({status:"account is private"});
            }
        });
    });
}

// /getProfileFriends           {login, email}
/**
 #### /getProfileFriends

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `email`

 **Optional parameters:** N/A

 Responds with a list of profile snapshots of requested account's friend. Responds with status "account is private" if the account is private and the user is not friends

 `login` - Email of the logged in account.

 `email` - Email of the requested account.
 */
function handleGetProfileFriends(request, response) {
    request = request.body;
    getAccount(request.email, function (accountOther) {
        getAccountFriends(request.email, function (friends) {
            if (request.login === request.email || !accountOther.priv || friends.includes(request.login)) {
                profileSnapshot(friends, request.login, function (snapshots) {
                    response.json(snapshots);
                });
            } else {
                response.json({status: "account is private"});
            }
        });
    });
}

// /getAddresses                {login}
/**
 #### /getAddresses

 **Auth tokens required:** Yes

 **Required parameters:** `login`

 **Optional parameters:** N/A

 Responds with the logged in user's addresses.

 `login` - Email of the logged in account.
 */
function handleGetAddresses(request, response) {
    request = request.body;
    con.query("select streetAddress, city, state, zipcode from Address where email=?",
        request.login,
        function (err, results) {
        if (err) throw err;
        response.json(results);
    });
}

// /addAddress                  {login, streetAddress, city, state, zipcode}
/**
 #### /addAddress

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `streetAddress`, `city`, `state`, `zipcode`

 **Optional parameters:** N/A

 Adds an address to the database with the requested parameters.

 `login` - Email of the logged in account.

 `streetAddress` - Street address of the new address.

 `city` - City of the new address.

 `state` - State of new address.

 `zipcode` - Zip code of new address.
 */
function handleAddAddress(request, response) {
    request = request.body;
    con.query("select addressID from Address where email=? order by addressID desc",
        request.login,
        function (err, results) {
        if (err) throw err;
        con.query("insert into Address (email, addressID, streetAddress, city, state, zipcode) values (?, ?, ?, ?, ?, ?)",
            [request.login, (results[0].addressID+1), request.streetAddress, request.city, request.state, request.zipcode],
            function (err, results) {
            if (err) throw err;
            response.json({status:"ok"});
        });
    });
}

// /deleteAddress               {login, addressID}
/**
 #### /deleteAddress

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `addressID`

 **Optional parameters:** N/A

 Delete the address with requested ID associated with the user's account.

 `login` - Email of the logged in account.

 `addressID` - ID of the address to delete.
 */
function handleDeleteAddress(request, response) {
    request = request.body;
    con.query("delete from Address where email=? and addressID=?",
        [request.login, request.addressID],
        function(err) {
        if (err) throw err;
        response.json({status:"ok"});
    });
}

// /changeAddress               {login, addressID, streetAddress, city, state, zipcode}
// NOTE: All parameters are optional except for login and addressID
/**
 #### /changeAddress

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `addressID`

 **Optional parameters:** `streetAddress`, `city`, `state`, `zipcode`

 Replace the values of the address with the requested values.

 `login` - Email of the logged in account.

 `addressID` - ID of the address to change.

 `streetAddress` - New street address of the address.

 `city` - New city of the address.

 `state` - New state of the address.

 `zipcode` - New zip code of the address.
 */
function handleChangeAddress(request, response) {
    request = request.body;
    con.query("select * from Address where email=? and addressID=?",
        [request.login, request.addressID],
        function (err, results) {
        if(err) throw err;
        let retStreetAddress = results[0].streetAddress;
        let retCity = results[0].city;
        let retState = results[0].state;
        let retZipcode = results[0].zipcode;
        let changeLog = [];

        if(request.hasOwnProperty('streetAddress')) {
            retStreetAddress = request.streetAddress;
            changeLog.push("streetAddress");
        }

        if(request.hasOwnProperty('city')) {
            retCity = request.city;
            changeLog.push("city");
        }
        if(request.hasOwnProperty('state')) {
            retState = request.state;
            changeLog.push("state");
        }
        if(request.hasOwnProperty('zipcode')) {
            retZipcode = request.zipcode;
            changeLog.push("zipcode");
        }

        con.query("update Address set streetAddress=?, " +
            "city=?, " +
            "state=?, " +
            "zipcode=? " +
            "where email=? " +
            "and addressID=?",
            [retStreetAddress, retCity, retState, retZipcode, request.login, request.addressID],
            function (err, results) {
                if (err) throw err;
                //console.log(results);
                response.json({status:"ok - values changed: " + changeLog});
            });
    });
}


// /getWalletFunds              {login}
/**
 #### /getWalletFunds

 **Auth tokens required:** Yes

 **Required parameters:** `login`

 **Optional parameters:** N/A

 Responds with the funds of the logged in user.

 `login` - Email of the logged in account.
 */
function handleGetWalletFunds(request, response) {
    request = request.body;
    getAccount(request.login, function (account) {
        response.json({amount:account.wallet});
    });
}

// /searchProfile               {login, name}
/**
 #### /searchProfile

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `name`

 **Optional parameters:** N/A

 Responds with the emails of the accounts associated with the requested name.

 `login` - Email of the logged in account.

 `name` - Name of the accounts being searched.
 */
function handleSearchProfile(request, response) {
    request = request.body;
    profileEmail(request.name, function (email) {
        response.json(email);
    });
}

// /allNames                    {}
/**
 #### /allNames

 **Auth tokens required:** No

 **Required parameters:** N/A

 **Optional parameters:** N/A

 Responds with the names of all accounts. Is used for autocomplete searching on the front end. This could use some improvement along with the autocomplete system.
 */
function handleAllNames(request, response) {
    con.query("select name from Account", function (err, result){
        if (err) throw err;
        response.json(result);
    });
}

// /allGifts
/**
 #### /allGifts

 **Auth tokens required:** No

 **Required parameters:** N/A

 **Optional parameters:** N/A

 Responds with the names of all gifts. Is used for autocomplete searching on the front end. This could use some improvement along with the autocomplete system.
 */
function handleAllGifts(request, response) {
    con.query("select name from Gift where priv=0", function (err, result){
        if (err) throw err;
        response.json(result);
    });
}


// /getTopGifts                 {name, receivingName, maxPrice, minPrice, remainingFunds, description, maxDate, minDate, link, sort, deadline}
//NOTE: All parameters are optional
/**
 #### /getTopGifts

 **Auth tokens required:** No

 **Required parameters:** N/A

 **Optional parameters:** `name`, `receivingName`, `maxPrice`, `minPrice`, `remainingFunds`, `description`, `maxDate`, `minDate`, `link`, `deadline`, `sort`

 Responds with the giftID, name, thumbnail, price, funds, receiving email and receiving name of all public gifts in order by popularity value. If a value is placed in the `sort` parameter, it will sort by that instead. This method is to be used for gift searching as well as displaying gifts on the home page. Possibly improve to respond with only a select number of gifts at a time to not cause overflow.

 `name` - Responds with gifts with this value somewhere in its title. This should be a string.

 `reveivingName` - Responds with gifts being received by users with names like this value. This should be a string.

 `maxPrice` - Responds with gifts with prices less than this value. This should be an integer in cents.

 `minPrice` - Responds with gifts with prices greater than this value. This should be an integer in cents.

 `remainFunds` - Responds with gifts that require an amount less than this value in order to be funded. This should be an integer in cents.

 `description` - Responds with gifts with this value somewhere in its description. This should be a string.

 `maxDate` - Responds with gifts posted before this value. This should be a string in YYYY-MM-DD format.

 `minDate` - Responds with gifts posted after this value. This should be a string in YYYY-MM-DD format.

 `link` - Responds with gifts with this value somewhere in its link. This should be a string.

 `deadline` - Responds with gifts with a deadline before this value. This should be a string in YYYY-MM-DD format.

 `sort` - Sorts the output by this value. This should be a string listing an entry of the gift table.
 */
function handleGetTopGifts(request, response) {
    request = request.body;
    //console.log(request.name);
    let sql = []

    let name = "";
    //let receivingEmails = "";
    let maxPrice = "";
    let minPrice = "";
    let remainingFunds = "";
    let description = "";
    let maxDate = "";
    let minDate = "";
    let link = "";
    let deadline = "";


    if(request.hasOwnProperty('name')) {
        name = " AND a.name like ?";
        sql.push('%' + request.name + '%');
    }//'%" + request.name + "%'

    if(request.hasOwnProperty('maxPrice')) {
        maxPrice = " AND a.price<=cast(? AS UNSIGNED)";
        sql.push(request.maxPrice);
    }

    if(request.hasOwnProperty('minPrice')) {
        minPrice = " AND a.price>=cast(? AS UNSIGNED)";
        sql.push(request.minPrice);
    }

    if(request.hasOwnProperty('remainingFunds')) {
        remainingFunds = " AND (a.price-a.funds)<=cast(? AS UNSIGNED)";
        sql.push(request.remainingFunds)
    }

    if(request.hasOwnProperty('description')) {
        description = " AND a.description like ?";
        sql.push('%' + request.description + '%');
    }

    if(request.hasOwnProperty('maxDate')) {
        maxDate = " AND a.date<= ?";
        sql.push(request.maxDate);
    }

    if(request.hasOwnProperty('minDate')) {
        minDate = " AND a.date>= ?";
        sql.push(request.minDate);
    }

    if(request.hasOwnProperty('link')) {
        link = " AND a.link like ?";
        sql.push('%' + request.link + '%');
    }

    if(request.hasOwnProperty('deadline')) {
        deadline = " AND a.deadline<= ?";
        sql.push(request.deadline)
    }

    if(request.hasOwnProperty('sort')) {
        sql.push(request.sort);
    } else {
        sql.push("popularity")
    }

    if(request.hasOwnProperty('receivingName')) {
        profileEmail(request.receivingName, function (emails) {
            let receivingEmails = " AND (";
            for (let i = 0; i < emails.length; i++) {
                if (i !== 0) {
                    receivingEmails += " OR ";
                }
                receivingEmails += "a.receivingEmail='" + emails[i].email + "'";
            }
            receivingEmails += ")";
            console.log("select giftID, name, thumbnail, price, funds, receivingEmail, deadline from Gift where priv=0"+
                name + receivingEmails + maxPrice + minPrice + remainingFunds + description + maxDate + minDate + link + deadline + " order by");
            console.log('%' + request.name + '%' + " - " + request.maxPrice + " - " + request.minPrice + " - " + request.remainingFunds + " - " + '%' + request.description + '%' + " - " + request.maxDate + " - " + request.minDate + " - " + '%' + request.link + '%' + " - " + request.deadline + " - ");
            con.query("select a.giftID, a.name, a.thumbnail, a.price, a.funds, a.receivingEmail, a.deadline, b.name as receivingName from Gift a, Account b where a.priv=0 and b.email=a.receivingEmail"+
                name + receivingEmails + maxPrice + minPrice + remainingFunds + description + maxDate + minDate + link + deadline + " order by ?",
                sql,
                function (err, results) {
                    if (err) throw err;
                    //(results);
                    response.json(results);
                });

        });
    } else {
        console.log("select giftID, name, thumbnail, price, funds, receivingEmail, deadline from Gift where priv=0"+
            name + maxPrice + minPrice + remainingFunds + description + maxDate + minDate + link + deadline + " order by ");
        console.log('%' + request.name + '%' + " - " + request.maxPrice + " - " + request.minPrice + " - " + request.remainingFunds + " - " + '%' + request.description + '%' + " - " + request.maxDate + " - " + request.minDate + " - " + '%' + request.link + '%' + " - " + request.deadline + " - ");
        con.query("select a.giftID, a.name, a.thumbnail, a.price, a.funds, a.receivingEmail, a.deadline, b.name as receivingName from Gift a, Account b where a.priv=0 and b.email=a.receivingEmail"+
            name + maxPrice + minPrice + remainingFunds + description + maxDate + minDate + link + deadline + " order by ?",
            sql,
            function (err, results) {
                if (err) throw err;
                //console.log(results);
                response.json(results);
            });
    }


}

// /contribute                  {login, giftID, amount}
/**
 #### /contribute

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`, `amount`

 **Optional parameters:** N/A

 Contributes the specified amount from the user's account wallet to the specified gift.

 `login` - Email of the logged in account.

 `giftID` - ID of the specified gift.

 `amount` - Amount in cents being contributed.
 */
function handleContribute(request, response) {
    request = request.body;
    getAccount(request.login, function(account) {
        getGift(request.giftID, function (gift) {
            let trimAmount = request.amount;
            if (request.amount + gift.funds > gift.price) {
                trimAmount = gift.price - gift.funds;
            }

            if (trimAmount > account.wallet) {
                response.json({status: "not enough money in wallet"});
            } else {
                let newWallet = account.wallet - trimAmount;
                let newFunds = gift.funds + trimAmount;
                con.query("update Account set wallet=? where email=?",
                    [newWallet, request.login],
                    function (err) {
                    if (err) throw err;
                    con.query("update Gift set funds=? where giftID=?",
                        [newFunds, request.giftID],
                        function (err) {
                        if (err) throw err;
                        con.query("select count(*) as n from Gift_Log where email=? " +
                            "and giftID=?",
                            [request.login, request.giftID],
                            function (err, result) {
                            if (err) throw err;
                            con.query("insert into Account_Activity (email, date, type, otherEmail, ID, val) " +
                                "values (?, convert('" + getCurrentDateTime() + "', datetime), 'CONTRIBUTE', ?, ?, ?)",
                                [request.login, gift.accountEmail, request.giftID, trimAmount],
                                function (err) {
                                if (err) throw err;
                                if (result[0].n > 0) {
                                    con.query("update Gift_Log set amount=amount+? where " +
                                        "email=? and giftID=?",
                                        [trimAmount, request.login, request.giftID],
                                        function (err, results) {
                                        if (err) throw err;
                                        response.json({status: "ok"});
                                    });
                                } else {
                                    con.query("insert into Gift_Log (giftID, email, amount) values(?, ?, ?)",
                                        [request.giftID, request.login, trimAmount],
                                        function (err, results) {
                                        if (err) throw err;
                                        response.json({status: "ok"});
                                    });
                                }
                            });
                        });
                    });
                });
            }
        });
    });
}

// /refund                      {login, giftID}
/**
 #### /refund

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`

 **Optional parameters:** N/A

 Refunds all contributions made to a specified gift by the user. The money is automatically added to the user's wallet.

 `login` - Email of the logged in account.

 `giftID` - Gift that contributions are being refunded from.
 */
function handleRefund(request, response) {
    request = request.body;
    getAccount(request.login, function (account) {
        getGift(request.giftID, function (gift) {
            con.query("select amount from Gift_Log where giftID=? and email=?",
                [request.giftID, request.login],
                function(err, result) {
                    if (err) throw err;
                    if(result.length === 0) {
                        response.json({status:"gift does not have an active donation"});
                    } else {
                        let newFunds = gift.funds - result[0].amount;
                        con.query("delete from Gift_Log where email=? and giftID =?",
                            [request.login, request.giftID],
                            function (err) {
                            if (err) throw err;
                            con.query("update Gift set funds=? where giftID=?",
                                [newFunds, request.giftID],
                                function (err) {
                                if (err) throw err;
                                let newWallet = result[0].amount + account.wallet;
                                con.query("update Account set wallet=? where email=?",
                                    [newWallet, request.login],
                                    function (err) {
                                        if (err) throw err;
                                        response.json({status: "ok"});
                                    });
                            });
                        });
                    }
                });
        });
    });
    /*con.query("select amount from Gift_Log where giftID='" + request.giftID + "' and email='" + request.login + "'",
        function(err, result) {
            if (err) throw err;
            let newWallet = account.wallet + entry.amount;
                con.query("update Account set wallet='" + newWallet + "' where email='" + entry.email + "'",
                    function (err) {
                        if (err) throw err;
                        con.query("delete from Gift_Log where email='" + entry.email + "'", function (err) {
                            if (err) throw err;
                        });
                    });

        });*/
}

// /getGiftSnapshot             {login, giftID, description}
// NOTE: description is an optional parameter. Set it to true to also return the description
// NOTE: giftID can either be a single value or an array
/**
 #### /getGiftSnapshot

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`

 **Optional parameters:** `description`

 Responds with the giftID, name, receivingEmail, price, funds, thumbnail and deadline of specified gift. If description is present and is also true, then the description of the gift will also be returned. `giftID` can also be a list of giftIDs, which will cause this command to return multiple gifts. Gift snapshots cannot be viewed if the gift is marked as private and the user is not friends with the poster.

 `login` - Email of the logged in account.

 `giftID` - Singular giftID or a list of giftIDs that gift snapshots of will be returned.

 `description` - If set to true the command will also return the description of the requested gifts. This is intended for use in places that require a larger gift component like the profile page.
 */
function handleGetGiftSnapshot(request, response) {
    request = request.body;
    let desc = false;
    if (request.hasOwnProperty("description") && request.description) {
        desc = true;
    }
    giftSnapshot(request.giftID, desc, function (gifts) {
        response.json(gifts);
    });
    /*
    if(Array.isArray(request.giftID)) {
        let idsSQL = ""
        request.giftID.forEach(function (entry) {
            if(idsSQL !== "") {
                idsSQL += " OR"
            }
            idsSQL += " giftID=" + entry;
        });
        if (request.hasOwnProperty("description") && request.description) {
            con.query("select giftID, name, receivingEmail, price, funds, thumbnail, deadline, description from gift where" + idsSQL + " group by giftID", function (err, results) {
                if (err) throw err;
                response.json(results);
            });
        } else {
            con.query("select giftID, name, receivingEmail, price, funds, thumbnail, deadline from gift where" + idsSQL + " group by giftID", function (err, results) {
                if (err) throw err;
                response.json(results);
            });
        }
    } else {
        getGift(request.giftID, function (gift) {
            if (request.hasOwnProperty("description") && request.description) {
                response.json({
                    giftID: gift.giftID,
                    name: gift.name,
                    email: gift.receivingEmail,
                    price: gift.price,
                    funds: gift.funds,
                    thumbnail: gift.thumbnail,
                    deadline: gift.deadline,
                    description: gift.description
                });
            } else {
                response.json({
                    giftID: gift.giftID,
                    name: gift.name,
                    email: gift.receivingEmail,
                    price: gift.price,
                    funds: gift.funds,
                    thumbnail: gift.thumbnail,
                    deadline: gift.deadline
                });
            }
        });
    }*/
}

// /getGiftInfo                 {login, giftID}
/**
 #### /getGiftInfo

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`

 **Optional parameters:** N/A

 Returns all the information on a gift. Will return a status of "gift is private" if the gift is marked as private and the user and the poster are not friends. ONLY USE IF ACCESSING A GIFT PAGE. USE /getGiftSnapshot WHEN DISPLAYING MULTIPLE GIFTS.

 `login` - Email of the logged in account.

 `giftID` - ID of the requested gift.
 */
function handleGetGiftInfo(request, response) {
    request = request.body;
    getGift(request.giftID, function(gift) {
        getAccountFriends(request.login, function (friends) {
            if(!gift.priv || friends.includes(gift.accountEmail)) {
                response.json(gift);
            } else {
                response.json({status:"gift is private"});
            }
        });
        //response.json(gift);
    });
}

// /getGiftImages               {login, giftID}
/**
 #### /getGiftImages

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`

 **Optional parameters:** N/A

 Responds with all the images associated with the requested gift. Will return a status of "gift is private" if the gift is marked as private and the user and the poster are not friends.

 `login` - Email of the logged in account.

 `giftID` - ID of requested gift.
 */
function handleGetGiftImages(request, response) {
    request = request.body;
    getGift(request.giftID, function(gift) {
        getAccountFriends(request.login, function (friends) {
            if(!gift.priv || friends.includes(gift.accountEmail)) {
                con.query("select image from Image where giftID=?", request.giftID, function (err, results) {
                    if (err) throw err;
                    response.json(results);
                });
            } else {
                response.json({status:"gift is private"});
            }
        });
    });
}

// /addComment                  {login, giftID, datetime, comment}
/**
 #### /addComment

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`, `datetime`, `comment`

 **Optional parameters:** N/A

 Adds a comment to the requested gift.

 `login` - Email of the logged in account.

 `giftID` - ID of the gift being commented on.

 `datetime` - Date and time the comment is posted. This is a string in the format "YYYY-MM-DD HH:MM:SS".

 `comment` - The contents of the comment.

 */
function handleAddComment(request, response) {
    request = request.body;
    getGift(request.giftID, function (gift) {
        getAccountFriends(request.login, function (friends) {
            if (!gift.priv || friends.includes(gift.accountEmail)) {
                con.query("insert into Gift_Comments (email, giftID, date, comment) values(?, ?, convert(?, datetime), ?)",
                    [request.login, request.giftID, request.datetime, request.comment],
                    function (err) {
                    if (err) throw err;
                    con.query("insert into Account_Activity (email, date, type, otherEmail, ID, val) values (?, convert(?, datetime), 'COMMENT', ?, ?, ?)",
                        [request.login, request.datetime, gift.accountEmail, request.giftID, request.comment],
                        function (err) {
                            if (err) throw err;
                            response.json({status: "ok"});
                        });
                });
            } else {
                response.json({status:"gift is private"});
            }
        });
    });
}

// /deleteComment               {login, giftID, datetime}
/**
 #### /deleteComment

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`, `datetime`

 **Optional parameters:** N/A

 Deletes the comment on the requested gift with the requested datetime (datetime is used as the id for the comment). Only the commenter and the poster of the gift can delete a comment.

 `login` - Email of the logged in account.

 `giftID` - ID of the gift that the deleted comment is on.

 `datetime` - The datetime of the gift being deleted. This is a string in the format "YYYY-MM-DD HH:MM:SS".
 */
function handleDeleteComment(request, response) {
    request = request.body;
    getGift(request.giftID, function (gift) {
        if(request.login === gift.accountEmail) {
            con.query("update Gift_Comments set email='[deleted]', comment='[deleted]' " +
                "where giftID=? and date=?",
                [request.giftID, request.datetime],
                function (err) {
                if (err) throw err;
                response.json({status:"ok"});
            })
        } else {
            con.query("update Gift_Comments set email='[deleted]', comment='[deleted]' " +
                "where giftID=? and date=? and email=?",
                [request.giftID, request.datetime, request.login],
                function (err) {
                    if (err) throw err;
                    response.json({status: "ok"});
                });
        }
    });
}

// /getComments                 {login, giftID}
/**
 #### /getComments

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`

 **Optional parameters:** N/A

 Responds with the email of the commenter, date of the comment, comment content, profile picture of commenter, and name of the commenter for each comment associated with the requested giftID. Status "gift is private" is returned if the gift is private and the logged in user and the gift poster are not friends.

 `login` - Email of the logged in account.

 `giftID` - ID of requested gift.
 */
function handleGetComments(request, response) {
    request = request.body;
    getGift(request.giftID, function (gift) {
        getAccountFriends(request.login, function (friends) {
            if (!gift.priv || friends.includes(gift.accountEmail)) {
                con.query("select gc.email, gc.date, gc.comment, a.pic, a.name from gift_comments gc inner join account a on gc.email = a.email and gc.giftID = ? order by gc.date desc", request.giftID, function(err, results) {
                    if (err) throw err;
                    results.forEach(result => {
                        result.pic = convertBlobToImg(result.pic);
                    });
                    response.json(results);
                });
            } else {
                response.json({status:"gift is private"});
            }
        });
    });
}





// /changeGift                  {login, giftID, name, description, priv, thumbnail, deadline}
// NOTE: All the request parameters are optional except for login and giftID
/**
 #### /changeGift

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `giftID`

 **Optional parameters:** `name`, `description`, `priv`, `thumbnail`, `deadline`

 Replaces the values of the requested gift with the requested parameters.

 `login` - Email of the logged in account.

 `giftID` - ID of the gift being changed.

 `name` - The new name of the gift.

 `description` - The new description of the gift.

 `priv` - The new privacy of the gift. 1 if private, 0 if it isn't.

 `thumbnail` - New thumbnail of the gift. This should be a link to the image.

 `deadline` - The new deadline of the gift. This should be a string in 'YYYY-MM-DD' format.
 */
function handleChangeGift(request, response) {
    request = request.body;
    getGift(request.giftID, function (gift) {
        if(gift.accountEmail===request.login) {
            let retName = gift.name;
            let retPriv = gift.priv;
            let retThumbnail = gift.thumbnail;
            let retDescription = gift.description;
            let retDeadline = gift.deadline;
            let changeLog = [];

            if(request.hasOwnProperty('name')) {
                retName = request.name;
                changeLog.push("name");
            }

            if(request.hasOwnProperty('priv')) {
                retPriv = request.priv;
                changeLog.push("priv");
            }
            if(request.hasOwnProperty('thumbnail')) {
                retThumbnail = request.thumbnail;
                changeLog.push("thumbnail");
            }
            if(request.hasOwnProperty('description')) {
                retDescription = request.description;
                changeLog.push("description");
            }
            if(request.hasOwnProperty('deadline')) {
                retDeadline = request.deadline;
                changeLog.push("deadline");
            }

            con.query("update Gift set name=?, " +
                "priv=?, " +
                "thumbnail=?, " +
                "description=?, " +
                "deadline=? " +
                "where giftID=?",
                [retName, retPriv, retThumbnail, retDescription, retDeadline, request.giftID],
                function (err, results) {
                    if (err) throw err;
                    //console.log(results);
                    response.json({status:"ok - values changed: " + changeLog});
                });
        } else {
            response.json({status:"cannot edit gift"});
        }
    });
}

/**
 #### /paypal/create-payment/

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `amount`

 **Optional parameters:** N/A

 Creates a Paypal payment to be executed. Must be called before calling '/paypal/execute-payment/'. Responds with the paymentID.

 `login` - Email of the logged in account.

 `amount` - The amount of money being transacted in cents.
 */
function handlePaypalCreatePayment(req, res) {
    //console.log(req.body);

    request.post(PAYPAL_API + '/v1/payments/payment',
        {
            auth: {
                user: PAYPAL_CLIENT,
                pass: PAYPAL_SECRET
                },
            body: {
                intent: 'sale',
                payer: { payment_method: 'paypal'},
                transactions: [{
                        amount: {
                                total: req.body.amount,
                                currency: 'USD'
                            }
                    }],
                redirect_urls: {
                        return_url: 'https://example.com',
                        cancel_url: 'https://example.com'
                    }
                },
            json: true
        }, function(err, response) {
            if (err) {
                console.error(err);
                return res.sendStatus(500);
            }
            // 3. Return the payment ID to the client
            res.json({
                    id: response.body.id
                });
        });

    //https://developer.paypal.com/docs/archive/checkout/how-to/server-integration/
}

/**
 #### /paypal/execute-payment/

 **Auth tokens required:** Yes

 **Required parameters:** `login`, `amount`, `paymentID`, `payerID`,

 **Optional parameters:** N/A

 Executes a created Paypal transaction. '/paypal/create-payment/' must be called first in order to retrieve the paymentID.

 `login` - Email of the logged in account.

 `amount` - The amount of money being transacted in cents.

 `paymentID` - ID of the payment.

 `payerID` - ID of the payer.
 */
function handlePaypalExecutePayment(req, res) {

    // 2. Get the payment ID and the payer ID from the request body.
    var paymentID = req.body.paymentID;
    var payerID = req.body.payerID;
    // 3. Call /v1/payments/payment/PAY-XXX/execute to finalize the payment.
    request.post(PAYPAL_API + '/v1/payments/payment/' + paymentID + '/execute',
        {
            auth: {
                user: PAYPAL_CLIENT,
                pass: PAYPAL_SECRET
                },
            body: {
                payer_id: payerID,
                transactions: [{
                    amount: {
                        total: req.body.amount,
                        currency: 'USD'
                    }
                }]
            },
            json: true
        },
        function(err, response) {
            let amount = response.body.transactions[0].amount.total;
            let id = response.body.id;
            if (err) {
                console.error(err);
                return res.sendStatus(500);
            }
            // 4. Return a success response to the client
            let request = {
                login: req.body.login,
                amount: amount * 100,
                transaction_id: id
            };
            handleAddWalletFunds(request);
            res.json({
                status: 'success'
            });
        });

// Run `node ./server.js` in your terminal

}

//                     {login, url}
function handleGetAmazonProductInfo(request, response) {

    let res = {
        responseStatus: '',
        productTitle: '',
        price: 0,
        image: ''
    };

    amazonReq.query({
        "url": request.body.url
    });

    amazonReq.headers({
        "x-rapidapi-key": "fcef7cf297msh35efe66d37e7d79p1d16a6jsnc0bb050aeb9d",
        "x-rapidapi-host": "axesso-axesso-amazon-data-service-v1.p.rapidapi.com",
        "useQueryString": true
    });

    amazonReq.end(function (resp) {
        if (resp.error) throw new Error(resp.error);
        res.responseStatus = resp.body.responseStatus;
        res.productTitle = resp.body.productTitle;
        res.price = resp.body.price;
        res.image = resp.body.mainImage.imageUrl;
        res.description = resp.body.productDescription;

        console.log(resp.body);

        response.json(res)
    });
}

//----------HELPER-FUNCTIONS----------

/**
 Retrieves all of the information on the specified account from the Account table in the database. ID is the email of the account.
 */
function getAccount(id, callback) {
    con.query("select * from account where email=? group by email", id, function (err, results) {
        if(err) throw err;
        // console.log(id);
        // console.log(results[0]);


          results = results[0];
        return callback(results);
    });
}

/**
 Checks if an account already exists with the email passed in through the id parameter.
 */
function existAccount(id, callback) {
    /*con.query("select count(email) as n from account where email=?", id, function (err, result) {
        if (err) throw err;
        // console.log(id);
        return callback(result[0].n > 0);
    });

     */
}

/**
 Retrieves all the information on the specified gift from the Gift table in the database. The id parameter of the giftID of the gift.
 */
function getGift(id, callback) {
    con.query("select * from gift where giftID=? group by giftID", id, function (err, results) {
        if(err) throw err;
        //console.log(id);
        //console.log(results);

        results = results[0];
        return callback(results);
    });
}

/**
 Checks if a gift already exists with the giftID passed in through the id parameter.
 */
function existGift(id, callback) {
    con.query("select count(giftID) as n from Gift where giftID=?", id, function (err, result) {
        if (err) throw err;
        //console.log(result);
        return callback(result[0].n > 0);
    });
}

/**
 Returns a list of the friends associated with account with the email passed in through the id parameter.
 */
function getAccountFriends(id, callback) {
    console.log("incoming id: ", id);
    con.query("select * from account_friends where email=?", id, function (err, results) {
        if(err) throw err;
        let ret = [];
        results.forEach(function (entry) {
            ret.push(entry.friends);
        });
        return callback(ret);
    });
}

/**
 Returns the email, name, and profile pictures of the requested accounts. The id parameter can be a singular account email or a list of emails. Login is the email of the logged in account.
 */
function profileSnapshot(id, login, callback) {
    if(Array.isArray(id)) {
        if(id.length === 0) {
            return callback({});
        }
        let idsSQL = ""
        id.forEach(function (entry) {
            if(idsSQL !== "") {
                idsSQL += " OR"
            }
            idsSQL += " email=?";
        });
        con.query("select email, name, pic, priv from Account where" + idsSQL + " group by email", id, function (err, results) {
            if (err) throw err;
            getAccountFriends(login, function (friends) {
                let ret = {};
                let i = 0;
                results.forEach(function (entry) {
                    if (login === entry.email || !entry.priv || friends.includes(entry.email)) {
                        ret[i] = {email: entry.email, name: entry.name, pic: convertBlobToImg(entry.pic)};
                    } else {
                        ret[i] = {status: "account is private", email: entry.email, name: entry.name, pic: convertBlobToImg(entry.pic)};
                    }
                    i++;
                });
                //Added to make it easier to get all friends to show on account
                return callback(ret);
            });
        })

    } else {
        getAccount(id, function (accountOther) {
            getAccountFriends(login, function (friends) {
                if (login === id || !accountOther.priv || friends.includes(id)) {
                    return callback({email: accountOther.email, name: accountOther.name, pic: convertBlobToImg(accountOther.pic)});
                } else {
                    //console.log(path.dirname(require.main.filename));
                    return callback({status: "account is private", email: accountOther.email, name: accountOther.name, pic: convertBlobToImg(accountOther.pic)});
                }
            });
        });
    }
}

/**
 Returns the giftID, name, receivingEmail, price, funds, thumbnail, and deadline of the requested gifts. If the description parameter is true, the description of the gifts will also be returned. The id parameter can be a singular giftID or a list of giftIDs.
 */
function giftSnapshot(id, description, callback) { //TODO: Add privacy testing
    if(!Array.isArray(id)) {
        getGift(id, function (gift) {
            if (description) {
                return callback({
                    giftID: gift.giftID,
                    name: gift.name,
                    email: gift.receivingEmail,
                    price: gift.price,
                    funds: gift.funds,
                    thumbnail: gift.thumbnail,
                    deadline: gift.deadline,
                    description: gift.description
                });
            } else {
                return callback({
                    giftID: gift.giftID,
                    name: gift.name,
                    email: gift.receivingEmail,
                    price: gift.price,
                    funds: gift.funds,
                    thumbnail: gift.thumbnail,
                    deadline: gift.deadline
                });
            }
        });
    } else if (id.length !== 0) {
        let idsSQL = "";
        id.forEach(function (entry) {
            if(idsSQL !== "") {
                idsSQL += " OR"
            }
            idsSQL += " giftID=?";
        });
        if(description) {
            con.query("select giftID, name, receivingEmail, price, funds, thumbnail, deadline, description from gift where" + idsSQL + " group by giftID", id,
                function (err, results) {
                if (err) throw err;
                return callback(results);
            });
        } else {
            con.query("select giftID, name, receivingEmail, price, funds, thumbnail, deadline from gift where" + idsSQL + " group by giftID", id, function (err, results) {
                if (err) throw err;
                return callback(results);
            });
        }
    } else {
        return callback([]);
    }
}

/**
 Used to convert row data packed objects to an array.
 */
function rowDataPacketToArray (rowDataPackets, type) {
    let ret = [];
    for(let i = 0; i < rowDataPackets.length; i++) {
        ret[i] = rowDataPackets[i].giftID;
    }
    return ret;
}

/**
 Returns a list of account emails with an account name like the name parameter.
 */
function profileEmail(name, callback) {
    con.query("select email, priv from Account where name like ?",
        '%' + name + '%',
        function (err, results) {
        if (err) throw err;
        return callback(results);
    });
}

/**
 * Converts sql blob to usable front end image
 * @param buffer
 * @returns {string}
 */
function convertBlobToImg(buffer) {
    if(buffer !== null) {
        return 'data:image/jpeg;base64,' + Buffer.from(buffer, 'binary').toString('base64');
    } else {
        return buffer;
    }

}

/**
 Adds the value of request.amount to the wallet of the account of request.login.
 */
function handleAddWalletFunds(request) {
    getAccount(request.login, function(account) {
        let newWallet = request.amount + account.wallet;
        con.query("update Account set wallet=? where email=?",
            [newWallet, request.login],
            function (err, results) {
                if (err) throw err;
            });
    });
}

/**
 Returns the current date as a string in 'YYYY-MM-DD' format.
 */
function getCurrentDate() {
    let today = new Date();
    let day = today.getDate();
    let month = today.getMonth()+1;
    let year = today.getFullYear();
    if(day < 10) {
        day = '0' + day;
    }
    if(month < 10) {
        month = '0' + month;
    }

    return (year + '-' + month + '-' + day);
}

/**
 Returns the current date and time as a string in 'YYYY-MM-DD HH:MM:SS' format.
 */
function getCurrentDateTime() {
    let today = new Date();
    let day = today.getDate();
    let month = today.getMonth()+1;
    let year = today.getFullYear();
    let hour = today.getHours();
    let minute = today.getMinutes();
    let second = today.getSeconds();
    if(day < 10) {
        day = '0' + day;
    }
    if(month < 10) {
        month = '0' + month;
    }
    if(hour < 10) {
        hour = '0' + hour;
    }
    if(minute < 10) {
        minute = '0' + minute;
    }
    if(second < 10) {
        second = '0' + second;
    }

    return (year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second);
}
